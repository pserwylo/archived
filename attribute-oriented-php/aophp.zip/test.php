<?php

/**
 * Here is my comment...
 * @access 1 Here we go.
 * @log info Bleh.
 */
function singleLog( )
{
    return "Single Log";
}

/**
 * Here is my comment...
 * @access 1 Here we go.
 * @log info Does some stuff.
 * @log info Oh, it also does some other stuff.
 * @log info And finally, it does nothing.
 */
function multiLog( )
{
    return "Multi Log";
}

function doesntLog( )
{
   return "Doesn't log" ;
}

function aophpLog( $function, $attributeValue )
{
    echo " [Logging: $function, $attributeValue] ";
    return true;
}

aophp_add_hook( "log", "aophpLog", 0, 0 );

echo singleLog( );
echo "\n";
echo multiLog( );
echo "\n";
echo doesntLog( );
echo "\n";
